#ifndef BMP390_H__
#define BMP390_H__

#include <stdint.h>
#include "user_define.h"
#include "bmp3_defs.h"


#if defined(USE_BMP390)


void StartBMP390Task(void const * argument);

#endif

#endif

